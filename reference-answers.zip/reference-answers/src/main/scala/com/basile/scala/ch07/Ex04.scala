package com.basile.scala.ch07

/**
 * Why do you think the Scala language designers provided the package object syntax instead of simply letting
 * you add functions and variables to a package?
 */
object Ex04 extends App {
  //It's not possible, JVM limitations
}
