package com.basile.scala.ch15

/**
 * Created by basile.duplessis on 10/01/14.
 *
 *   public final <U extends java/lang/Object> void foreach(scala.Function1<java.lang.Object, U>);
 *   => foreach must not return any value
 *
 */
object Ex09 {

}
