package com.basile.scala.ch01

/**
 * Using BigInt , compute 2^1024
 */
object Ex06 extends App {

  println(
    BigInt(2).pow(1024)
  )

}
