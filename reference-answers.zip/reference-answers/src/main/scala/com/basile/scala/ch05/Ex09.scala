package com.basile.scala.ch05

/**
 * Reimplement the class of the preceding exercise in Java, C#, or C++ (your choice).
 *
 * How much shorter is the Scala class?
 */
object Ex09 extends App {



}
