package com.basile.scala.ch02

/**
 * Solve the preceding exercise without writing a loop. (Hint: Look at the StringOps Scaladoc.)
 */
object Ex07 extends App {

  assert( "Hello".map(_.toLong).product == 9415087488L )

}
