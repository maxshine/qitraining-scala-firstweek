package com.basile.scala.ch07

import java._
import javax._


/**
 * What is the effect of import java._ import javax._ Is this a good idea?
 */
object Ex08 extends App {
  //Will not compile such code : lang.Boolean

}
