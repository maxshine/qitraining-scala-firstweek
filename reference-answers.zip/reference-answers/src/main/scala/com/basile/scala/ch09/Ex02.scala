package com.basile.scala.ch09

/**
 * Write a Scala program that reads a file with tabs, replaces each tab with spaces so that tab stops are
 * at n -column boundaries, and writes the result to the same file.
 */
object Ex02 extends App {



}
