package com.basile.scala.ch11

/**
 * According to the precedence rules, how are 3 + 4 -> 5 and 3 -> 4 + 5 evaluated?
 */
object Ex01 extends App {
  //From left to right
}
