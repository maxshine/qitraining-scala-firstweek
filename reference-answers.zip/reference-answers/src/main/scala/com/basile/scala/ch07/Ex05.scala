package com.basile.scala.ch07


/**
 * What is the meaning of private[com] def giveRaise(rate: Double)? Is it useful?
 */
object Ex05 extends App {
  //Function only accessible through a child package of com - it's not very useful if everything is in com
}
