package com.basile.scala.ch02

/**
 * Come up with one situation where the assignment x = y = 1 is valid in Scala. (Hint: Pick a suitable type for x .)
 */
object Ex03 extends App {

  var y:Int = 0

  val x: Unit = y = 1

}
