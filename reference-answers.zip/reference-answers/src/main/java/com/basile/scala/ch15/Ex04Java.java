package com.basile.scala.ch15;

public class Ex04Java {
	public static void main (String[] args){
		Ex04 ex = new Ex04();	
		
		int values[] = {2,4};
		
		int result = ex.sum(values);
		
		System.out.println(result);
	}
}